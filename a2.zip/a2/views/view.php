<!DOCTYPE html>
<html>
	<head>
		<title>Fisher Price - My First Model View Control</title>
	</head>
	<body>
		<h1>Hello From My View!</h1>
		<ul>
			<li><?php echo 'User ID: '.$userid ?></li>
			<li><?php echo 'First Name: '.$firstName; ?></li>
			<li><?php echo 'Last Name: '.$lastName; ?></li>
			<li><?php echo 'Email: '.$email; ?></li>
			<li><?php echo 'Role: '.$role; ?></li>	
		</ul>
	</body>
</html>